package com.incapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.incapp.models.Doctor;

@SpringBootApplication
public class DoctorsResTfulWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorsResTfulWebservicesApplication.class, args);
		
	}

}
