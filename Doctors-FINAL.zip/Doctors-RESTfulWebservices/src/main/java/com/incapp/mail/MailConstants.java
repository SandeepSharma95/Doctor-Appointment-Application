package com.incapp.mail;

public class MailConstants {
//	final static public String EMAIL="Your Gmail ID";
//	final static public String PASSWORD="Your Generated Password";
	final static public String EMAIL="incappclassroom23@gmail.com";
	final static public String PASSWORD="iodx fgep tzgj lirq";
}
